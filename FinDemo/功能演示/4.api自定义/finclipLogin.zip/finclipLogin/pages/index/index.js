// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    name: '',
    token : '',
    url : ''
  },
  // 事件处理函数
  bindViewTap() {
    const _this = this;
    ft.finclipLogin({
      url:'https://www.finclip.com',
      success: function (res) {
        console.log(res);
        _this.setData({
          name : res.name,
          token : res.token,
          url : res.url
        })
      },
      fail: function (res) {
        console.log(res);
      }
    });
  },
  onLoad() {
    this.setData({
      name: '点击调用自定义api'
    })
  }
})
